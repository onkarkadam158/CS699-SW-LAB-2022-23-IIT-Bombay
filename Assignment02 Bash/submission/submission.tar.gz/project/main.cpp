#include<iostream>
using namespace std;
#include"hdr.h"
int main()
{
    int a=100,b=80;
    int compute=tempfunction(a,b);
    cout<<compute;
    return 0;
}