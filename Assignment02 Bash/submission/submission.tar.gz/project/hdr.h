int tempfunction(int a,int b)
{
    int c=12;
    int d=13;
    int compute=(a*b+c+d)-a*c + b*d;
    return compute;
}